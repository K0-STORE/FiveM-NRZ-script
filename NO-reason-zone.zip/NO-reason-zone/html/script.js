window.addEventListener('message', function(event) {
    if (event.data.action === "show") {
        document.getElementById("nrz").style.display = "block";
    } else if (event.data.action === "hide") {
        document.getElementById("nrz").style.display = "none";
    }
});
