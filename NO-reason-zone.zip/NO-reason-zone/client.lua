local zone = {
    coords = vector3(200.0, -1000.0, 30.0),
    radius = 100.0,
    color = {r = 255, g = 0, b = 0, a = 100},
    blip = nil
}

local isInZone = false

Citizen.CreateThread(function()
    zone.blip = AddBlipForRadius(zone.coords.x, zone.coords.y, zone.coords.z, zone.radius)
    SetBlipColour(zone.blip, 1)
    SetBlipAlpha(zone.blip, 128)
    SetBlipAsShortRange(zone.blip, true)

    local blipMarker = AddBlipForCoord(zone.coords.x, zone.coords.y, zone.coords.z)
    SetBlipSprite(blipMarker, 161)
    SetBlipColour(blipMarker, 1)
    SetBlipScale(blipMarker, 1.0)
    SetBlipAsShortRange(blipMarker, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("No Reason Zone")
    EndTextCommandSetBlipName(blipMarker)
end)

Citizen.CreateThread(function()
    while true do
        Wait(0)
        DrawMarker(1, zone.coords.x, zone.coords.y, zone.coords.z - 1.0, 0, 0, 0, 0, 0, 0, zone.radius * 2.0, zone.radius * 2.0, 2.0, zone.color.r, zone.color.g, zone.color.b, zone.color.a, false, false, 2, false, nil, nil, false)
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(500)
        local player = PlayerPedId()
        local playerCoords = GetEntityCoords(player)
        local dist = #(playerCoords - zone.coords)

        if dist <= zone.radius and not isInZone then
            isInZone = true
            SendNUIMessage({ action = "show" })
        elseif dist > zone.radius and isInZone then
            isInZone = false
            SendNUIMessage({ action = "hide" })
        end
    end
end)
