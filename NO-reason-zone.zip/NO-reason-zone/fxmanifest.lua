fx_version 'cerulean'
game 'gta5'

author 'nekolas'
description 'NRZ script by K0-STORE in github'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'

ui_page 'html/index.html'
files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
